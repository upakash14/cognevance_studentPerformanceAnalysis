import pandas as pd
import numpy as np

df = pd.read_csv("customer_behavior_dataset.csv")

features = ["Age","Tenure_Months","Monthly_Spend","Orders_Last_90_Days","Support_Tickets"]
X = df[features]
X = (X - X.mean()) / X.std()
Xb = np.c_[np.ones(len(X)), X.to_numpy()]
y = df["Churn"].to_numpy().reshape(-1,1)

w = np.zeros((Xb.shape[1],1))
for _ in range(2500):
    p = 1/(1+np.exp(-np.clip(Xb @ w, -40, 40)))
    grad = Xb.T @ (p-y) / len(y)
    w -= 0.08 * grad

pred = (1/(1+np.exp(-np.clip(Xb @ w, -40, 40))) >= 0.5).astype(int).ravel()
df["Predicted_Churn"] = pred
df.to_csv("customer_behavior_scored.csv", index=False)

print("Model accuracy:", (pred == y.ravel()).mean())
