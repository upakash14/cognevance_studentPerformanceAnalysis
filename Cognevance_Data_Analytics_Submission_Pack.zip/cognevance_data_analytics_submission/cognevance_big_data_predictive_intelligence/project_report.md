# Big Data Analytics & Predictive Intelligence

## Objective
Develop a complete analytics workflow with preprocessing, predictive modeling, KPI analysis, and dashboard-ready outputs.

## Dataset
A synthetic customer-behavior dataset with **900 records** covering age, tenure, monthly spend, order activity, support tickets, and churn.

## Methodology
1. Collected/generated structured customer data.
2. Checked ranges and standardized model inputs.
3. Engineered standardized predictive features.
4. Built a binary churn prediction model using logistic regression with gradient descent.
5. Generated customer-level churn predictions.
6. Produced KPI data and dashboard-ready outputs.
7. Documented the workflow and recommendations.

## Key KPIs
- Customers: **900**
- Churn rate: **53.56%**
- Average monthly spend: **₹2,783.94**
- Average orders in the last 90 days: **2.95**
- Model accuracy on the sample data: **0.656**

## Business Recommendations
- Prioritize high-support-ticket and short-tenure customers for retention campaigns.
- Monitor churn risk together with customer value.
- Use the model as a decision-support tool, not an automatic final decision.
- Add more historical time-series and interaction data for a production-grade model.

## Dashboard
`dashboard_kpis.csv` and the two PNG charts can be imported into Power BI or Tableau to build the required interactive dashboard.

## Files
Dataset, scored dataset, predictive model script, KPI CSV, charts, report and README.
