# Dashboard Build Guide

## Power BI
1. Open Power BI Desktop.
2. Get Data → Text/CSV.
3. Import `dashboard_kpis.csv`.
4. Import `customer_behavior_scored.csv`.
5. Create KPI cards for customer count, churn rate and average spend.
6. Create a column chart for average spend by churn.
7. Create a scatter chart for tenure vs monthly spend.
8. Add slicers for churn and customer attributes.
9. Save as `cognevance_predictive_dashboard.pbix`.

## Tableau
1. Connect to `dashboard_kpis.csv` and `customer_behavior_scored.csv`.
2. Create KPI cards and charts using the same measures.
3. Add filters for churn, tenure and customer activity.
4. Save the workbook as `cognevance_predictive_dashboard.twbx`.
