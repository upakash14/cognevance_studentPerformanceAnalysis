# Cognevance Project - Big Data Analytics & Predictive Intelligence

## Objective
Build a predictive analytics workflow and dashboard-ready output.

## Tools
Python, Pandas, NumPy, Power BI/Tableau

## How to run
```bash
pip install pandas numpy matplotlib
python predictive_analytics.py
```

## Deliverables
Dataset, scored dataset, predictive analytics code, KPI output, charts, report, and Power BI/Tableau build guide.

Repository naming format: `cognevance_bigDataPredictiveIntelligence`
