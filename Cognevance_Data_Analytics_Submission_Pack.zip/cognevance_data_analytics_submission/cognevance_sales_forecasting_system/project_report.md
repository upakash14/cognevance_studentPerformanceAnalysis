# Sales Forecasting System

## Objective
Build a forecasting model to estimate future sales from historical business data.

## Dataset
Monthly sample sales data from January 2023 to December 2025.

## Methodology
1. Loaded monthly sales history with Pandas.
2. Inspected trends and seasonality.
3. Used NumPy linear regression (`polyfit`) to model the overall trend.
4. Forecast the next six months.
5. Visualized historical sales and forecast values.

## Key Findings
- Sales increased by approximately **88.2%** from the first month to the final historical month.
- Highest historical sales occurred in **May 2025**.
- The forecast indicates a continued upward trend under the linear-trend assumption.

## Business Recommendations
- Use the forecast as a baseline for inventory and staffing.
- Compare forecast values with actual monthly results and retrain/adjust the model regularly.
- Add promotional calendars, product-level sales and seasonality features for a stronger future model.

## Files
- `historical_sales.csv`
- `sales_forecast.csv`
- `sales_forecasting.py`
- `sales_trend.png`
- `sales_forecast.png`
- `project_report.md`
