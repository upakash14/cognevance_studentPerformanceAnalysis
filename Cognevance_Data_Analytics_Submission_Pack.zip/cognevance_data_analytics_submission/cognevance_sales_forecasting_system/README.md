# Cognevance Project - Sales Forecasting System

## Objective
Predict future sales using historical business data.

## Tools
Python, Pandas, NumPy, Matplotlib

## How to run
```bash
pip install pandas numpy matplotlib
python sales_forecasting.py
```

## Deliverables
Historical dataset, forecast dataset, forecasting code, charts, and business report.

Repository naming format: `cognevance_salesForecastingSystem`
