import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv("historical_sales.csv", parse_dates=["Month"])
t = np.arange(len(df))
coef = np.polyfit(t, df["Sales"], 1)
future_t = np.arange(len(df), len(df) + 6)
future_dates = pd.date_range(df["Month"].iloc[-1] + pd.offsets.MonthBegin(1), periods=6, freq="MS")
forecast = np.polyval(coef, future_t)

forecast_df = pd.DataFrame({"Month": future_dates, "Forecast_Sales": forecast})
forecast_df.to_csv("sales_forecast.csv", index=False)
print(forecast_df)

plt.plot(df["Month"], df["Sales"], label="Historical")
plt.plot(future_dates, forecast, marker="o", label="Forecast")
plt.legend()
plt.show()
