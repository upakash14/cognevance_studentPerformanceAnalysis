# Cognevance Data Science & Data Analytics - Submission Pack

This package follows the uploaded internship brief:
- Level 1: Student Performance Analysis
- Level 2: Sales Forecasting System
- Level 3: Big Data Analytics & Predictive Intelligence

## GitHub
Create three separate public/private repositories, using:
1. `cognevance_studentPerformanceAnalysis`
2. `cognevance_salesForecastingSystem`
3. `cognevance_bigDataPredictiveIntelligence`

Upload each corresponding folder to its repository, then send all repository links to:
support@cognevance.online

## Important
The third project's interactive dashboard must be built in Power BI or Tableau because the internship brief specifically asks for one. A step-by-step guide is included in that folder.

This package contains sample/synthetic datasets where the brief permits creating a sample dataset. Do not claim these datasets are proprietary company data.
