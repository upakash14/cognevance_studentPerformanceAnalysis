# Student Performance Analysis

## Objective
Analyze student academic performance and identify patterns in marks, attendance, and study behavior.

## Dataset
A sample dataset of 80 students was created for this project, which is explicitly permitted by the internship brief.

## Methodology
1. Checked ranges and basic data quality.
2. Used attendance, study hours, internal marks, and final marks as analytical variables.
3. Created histogram, bar chart, pie chart, and scatter plot.
4. Measured the relationship between attendance and overall marks.
5. Compared average performance across departments.

## Key Findings
- The correlation between attendance and overall marks is **0.05**.
- The department with the highest average marks in this sample is **CSE**.
- The department with the lowest average marks in this sample is **ISE**.
- Students with stronger attendance generally show stronger academic performance in the sample.

## Recommendations
- Monitor students whose attendance falls below 75%.
- Provide targeted academic support to lower-performing groups.
- Encourage consistent study routines rather than last-minute preparation.
- Review attendance and marks together to identify students who need intervention.

## Files
- `student_performance_dataset.csv`
- `student_performance_analysis.py`
- Four PNG charts
- `README.md`
