import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("student_performance_dataset.csv")
print(df.head())
print(df.describe(include="all"))

print("\nAverage marks by department:")
print(df.groupby("Department")["Overall_Marks"].mean().sort_values(ascending=False))

print("\nAttendance/marks correlation:",
      df["Attendance_Pct"].corr(df["Overall_Marks"]))

plt.hist(df["Overall_Marks"], bins=10)
plt.title("Distribution of Overall Marks")
plt.xlabel("Overall Marks")
plt.ylabel("Number of Students")
plt.show()
