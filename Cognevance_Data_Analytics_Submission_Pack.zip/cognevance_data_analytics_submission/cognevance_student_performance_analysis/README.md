# Cognevance Project - Student Performance Analysis

## Objective
Analyze student marks, attendance, and performance patterns.

## Tools
Python, Pandas, Matplotlib

## How to run
```bash
pip install pandas matplotlib
python student_performance_analysis.py
```

## Deliverables
Dataset, analysis script, visualization charts, and project report.

Repository naming format: `cognevance_studentPerformanceAnalysis`
